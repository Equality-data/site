import os
from mnemonic import Mnemonic
import bip32utils
import random
from bit.network import NetworkAPI
from pystyle import Colors, Colorate
import threading
from time import sleep

color = random.randint(1,7)
if color == 1:
    color=Colors.purple_to_blue
if color == 2:
    color=Colors.cyan_to_blue
if color == 3:
    color=Colors.green_to_blue
if color == 4:
    color=Colors.green_to_yellow
if color == 5:
    color=Colors.green_to_cyan 
if color == 6:
    color=Colors.yellow_to_red
if color == 7:
    color=Colors.purple_to_red
    

print(Colorate.Vertical(color,'''


$$$$$$$$\ $$\                           $$\      $$\ $$\                               
$$  _____|\__|                          $$$\    $$$ |\__|                              
$$ |      $$\  $$$$$$\   $$$$$$\        $$$$\  $$$$ |$$\ $$$$$$$\   $$$$$$\   $$$$$$\  
$$$$$\    $$ |$$  __$$\ $$  __$$\       $$\$$\$$ $$ |$$ |$$  __$$\ $$  __$$\ $$  __$$\ 
$$  __|   $$ |$$ |  \__|$$$$$$$$ |      $$ \$$$  $$ |$$ |$$ |  $$ |$$$$$$$$ |$$ |  \__|
$$ |      $$ |$$ |      $$   ____|      $$ |\$  /$$ |$$ |$$ |  $$ |$$   ____|$$ |      
$$ |      $$ |$$ |      \$$$$$$$\       $$ | \_/ $$ |$$ |$$ |  $$ |\$$$$$$$\ $$ |      
\__|      \__|\__|       \_______|      \__|     \__|\__|\__|  \__| \_______|\__|      
                                                                                       
                                                                                       
                                                                                       

version:premium
                        thanks for BUYING 
                             ╔══════════════════════════════════════════════════╗
                             ║  https://discord.gg/WxvPDC7YXs                   ║
                             ╚══════════════════════════════════════════════════╝
                                                                                                                             
''',True))

c=[0]

def infothread():
    cps=0
    while True:
        sleep(1)
        os.system('title  Checked: '+str(c[0])+' CPS: '+str(c[0]-cps)+'Discord: https://discord.gg/WxvPDC7YXs')
        cps=0
        cps=c[0]

        
def run(showing,semaphore):
    while True:
        try:
            #genarate mnonic phrase
            mnemonic = Mnemonic("english")
            words = mnemonic.generate(strength=128)

            #getting address
            seed = mnemonic.to_seed(words)
            key = bip32utils.BIP32Key.fromEntropy(seed)
            address = key.Address()
            WIF = key.WalletImportFormat()

            #get balance
            balance_satoshi = NetworkAPI.get_balance(address)
            balance_btc = balance_satoshi / 100000000

            
            with semaphore:
                print(Colorate.Color(Colors.red,(str(balance_btc)+' | address: '+address+' | phrase: '+words)))
            if balance_btc > 0:
                          with semaphore:
                              hitstxt = open("hits.txt", "a")
                              hitstxt.write('\n')
                              hitstxt.write('HIT BAL: '+str(balance_btc)+' BTC | address: '+address+' | phrase: '+words)
                              hitstxt.close()
                          print('HIT BAL: '+str(balance_btc)+' | phrase: '+words+' | address: '+address)

            with semaphore:
                    c[0]=c[0]+1
        except:
            pass


            
semaphore = threading.Semaphore(1)
threads = []
print('')
showing = 'yes'

t = threading.Thread(target=infothread, args=())
threads.append(t)
t.start()
print(Colorate.Color(Colors.red,'               (+) Miner started '))
for i in range(200):
    try:
        t = threading.Thread(target=run, args=(showing,semaphore))
        threads.append(t)
        t.start()
    except:
        break

while True:
    sleep(1)
for t in threads:
    t.join()

    
